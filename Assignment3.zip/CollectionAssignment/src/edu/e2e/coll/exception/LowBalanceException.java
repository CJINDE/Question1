package edu.e2e.coll.exception;

public class LowBalanceException extends Exception{

}
